package loadData;

import bikeStationAndTrip.BikeStations;
import graphs.WeightedGraph;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

  public  class GetBikeDataAndAddGraphs {
      static Graph graph = new SingleGraph("Tutorial 1");
      static  int countDataFromFile = 0 ;
      static WeightedGraph<BikeStations> bikeStationsWeightedGraph = new WeightedGraph<>();

      public static WeightedGraph<BikeStations> getBikeStationsWeightedGraph() {
          return bikeStationsWeightedGraph;
      }

      public static  int countBikeStationNumberInFile() {

        try {
            BufferedReader br = new BufferedReader(new FileReader("BikeStations.csv"));
            while (( br.readLine()) != null) {

                countDataFromFile++;

            }

        }catch (FileNotFoundException e) {
            System.out.println(e.getCause());
        }
        catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return countDataFromFile;
    }

    public static void addVertex() {
   BikeStations bikeStations ;
        String line = "";

          try {
              BufferedReader br = new BufferedReader(new FileReader("BikeStations.csv"));
              while ((line = br.readLine()) != null) {
                  String[] fileArray = line.split(",");
                  String id = fileArray[0];
                  System.out.println(id);
                  if(id.equals("id")) {

                  }else {
                      int convertIdToId = Integer.valueOf(id);

                    //  bikeStations = new BikeStations(convertIdToId);
                  //    bikeStationsWeightedGraph.addVertex(bikeStations);
                      graph.addNode(id);

                     // graph.display();
                      System.out.println(id);
                  }
              }
          }catch (FileNotFoundException e) {
              System.out.println(e.getCause());
          }
          catch (IOException e) {
              System.out.println(e.getMessage());
          }


    }

//      private void pullVertexDataFromCsvFile() {
//          BikeStations bikeStations;
//
//
//          String line = "";
//
//          try {
//              BufferedReader br = new BufferedReader(new FileReader("BikeStations.csv"));
//              while ((line = br.readLine()) != null) {
//                  String[] fileArray = line.split(",");
//                  String id = fileArray[0];
//                  String name = fileArray[1];
//                  String latitude = fileArray[2];
//                  String longitude = fileArray[3];
//
//
//
//                  // this if else to make sure not get all id name latitude longtitude names
//
//
//                  if(id.equals("id") && name.equals("name") && latitude.equals("latitude") && longitude.equals("longitude")) {
//
////                    System.out.println(name);
////                    System.out.println(id);
////                    System.out.println(latitude);
//
//
//                  }
//                  else {
//                      // because all data came as String we convertname as we need
//
//                      int convertId = Integer.parseInt(id);
//                      double convertToLatitudeDouble = Double.parseDouble(latitude);
//                      double convertTolongitudeToDouble = Double.parseDouble(longitude);
//
//                      // we add all data to BikeSatation object to able to add AddVertex array
//                      bikeStations = new BikeStations(convertId,name,convertToLatitudeDouble,convertTolongitudeToDouble);
//
//                      this.addVertex(bikeStations);
//                      // all we add bike id to graph for jFrame the one came from jar
//                      this.graph.addNode(id);
//
//
//
//
//                      //   bikeStations = new BikeStations(fileArray[0],"nebil",122.0,22.0,"uu",);
//
//                  }
//
//              }
//
//
//          }catch (FileNotFoundException e) {
//              System.out.println(e.getCause());
//          }
//          catch (IOException e) {
//              System.out.println(e.getMessage());
//          }
//
//
//      }





}
