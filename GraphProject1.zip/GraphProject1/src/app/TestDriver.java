package app;

import bikeStationAndTrip.BikeStations;
import graphs.WeightedGraph;
import org.graphstream.graph.Graph;
import org.graphstream.graph.implementations.SingleGraph;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestDriver {
    /*
     this int variable is for count how many bikeStation we have in file and count them to make maxnumber of
     vertex
     */
    static int countDataFromFile = 0;
    static WeightedGraph<BikeStations> input;
    static BikeStations bikeStations;
    static Graph graph = new SingleGraph("Tutorial 1");

    public static void main(String[] args) {


      input = new WeightedGraph<>();

        getAllDataFromCsvFileForVertex();
        getEdgeFromCsvFileAndAddToVertex();
        graph.display();
        input.busyStation();
        System.out.println(input);

    }

/*
this method get all data from csv file and add vertex and graphs
 */

    public static void getAllDataFromCsvFileForVertex() {
        BikeStations bikeStations ;
        String line = "";

        try {
            BufferedReader br = new BufferedReader(new FileReader("BikeStations.csv"));
            while ((line = br.readLine()) != null) {
                String[] fileArray = line.split(",");
                String id = fileArray[0];
                String name = fileArray[1];
               // System.out.println(id);
                if(id.equals("id") && name.equals("name")) {

                }else {


                    int convertIdToId = Integer.valueOf(id);
                    bikeStations = new BikeStations(convertIdToId,name);
                    input.addVertex(bikeStations);
                    graph.addNode(id);


                }
            }
        }catch (FileNotFoundException e) {
            System.out.println(e.getCause());
        }
        catch (IOException e) {
            System.out.println(e.getMessage());
        }


    }



/*
this method get all data from cvs file and add edd in vertex and graphs
 */


    public static void getEdgeFromCsvFileAndAddToVertex() {

        //BikeTrips bikeTrips;

        String line = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader("BikeTrips.csv"));
            while ((line = br.readLine()) != null) {
                String[] fileArray = line.split(",");

                String trip_id = fileArray[0];
                String from_station_id = fileArray[5];
                String to_station_id = fileArray[7];



                // if else is for to make sure not get all this STring name
                if(trip_id.equals("trip_id") &&   from_station_id.equals("from_station_id") && to_station_id.equals("to_station_id") ){

                }
                else {
                    // because all data came as String we convert them as we need for BikeTrips object

                    int convert_to_station_id = Integer.parseInt(to_station_id);
                    int convert_from_station_id = Integer.parseInt(from_station_id);
                    int convert_trip_id = Integer.parseInt(trip_id);

                    graph.setStrict(false);
                    graph.setAutoCreate( true );
                    graph.addEdge(trip_id,from_station_id,to_station_id);


                  //  System.out.println(convert_to_station_id);


                 //  input.addEdge(findBike(convert_from_station_id),findBike(convert_to_station_id),1);

                 input.addEdge(new BikeStations(convert_from_station_id),new BikeStations(convert_to_station_id),1);






                }


            }



        }catch (FileNotFoundException e) {
            System.out.println(e.getCause());
        }
        catch (IOException e) {
            System.out.println(e.getMessage());
        }



    }







/*
this method is get number of bikestation because we wanna use in WeightedGraphs class to make
maxofvertex and adjecent martix
 */


    public static  int numberOfBikeStation() {

        try {
            BufferedReader br = new BufferedReader(new FileReader("BikeStations.csv"));
            while (( br.readLine()) != null) {

                countDataFromFile++;

            }

        }catch (FileNotFoundException e) {
            System.out.println(e.getCause());
        }
        catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return countDataFromFile;
    }













}
