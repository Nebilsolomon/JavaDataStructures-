package bikeStationAndTrip;

import java.util.Objects;

public class BikeTrip {
    protected  int trip_id;
    protected int from_station_id;
    protected int to_station_id;

    public BikeTrip( int trip_id, int from_station_id , int to_station_id) {

        this.trip_id = trip_id;
        this.from_station_id = from_station_id;
        this.to_station_id = to_station_id;
    }

    public int getTo_station_id() {
        return to_station_id;
    }

    public int getFrom_station_id() {
        return from_station_id;
    }

    public int getTrip_id() {
        return trip_id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BikeTrip bikeTrip = (BikeTrip) o;
        return trip_id == bikeTrip.trip_id &&
                from_station_id == bikeTrip.from_station_id &&
                to_station_id == bikeTrip.to_station_id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(trip_id, from_station_id, to_station_id);
    }

    @Override
    public String toString() {
        return "BikeTrip{" +
                "trip_id=" + trip_id +
                ", from_station_id=" + from_station_id +
                ", to_station_id=" + to_station_id +
                '}';
    }
}
