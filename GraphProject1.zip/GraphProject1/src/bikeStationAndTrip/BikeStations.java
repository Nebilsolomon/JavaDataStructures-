package bikeStationAndTrip;

import java.util.Objects;

public class BikeStations {
    protected int id;
    protected String name;

    public BikeStations( int id, String name) {
        this.id = id;
        this.name = name;
    }
    public BikeStations(int id) {
        this.id = id;
}

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BikeStations that = (BikeStations) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "BikeStations{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
