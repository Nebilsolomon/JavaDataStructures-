package graphs;

import app.TestDriver;

public class WeightedGraph<T> implements WeightedGraphInterface<T> {


    public static final int NULL_EDGE = 0;
    /*
  this  TestDriver.numberOfBikeStation(); came from TestDriver class i count that how many station are
  there in CSV file and return number of them so that i can assignet to maxVertices;
     */
    private static final int DEFCAP = TestDriver.numberOfBikeStation();
    private int  numVertices;
    private int maxVertices;
    private T[] vertices;
    private int[][] edges;



    public WeightedGraph() {

        numVertices = 0;
        maxVertices = DEFCAP;
        vertices = (T[]) new Object[DEFCAP];
        edges = new int[DEFCAP][DEFCAP];
    }




/*
this method add vertex to vertex array
 */

    @Override
    public void addVertex(T vertex) {
        vertices[numVertices] = vertex;

       String convertVertexIntex = String.valueOf(numVertices);
        for (int index = 0; index < numVertices; index++)
        {
            edges[numVertices][index] = NULL_EDGE;
            edges[index][numVertices] = NULL_EDGE;
        }
        numVertices++;

    }


    /*
    this method check if there is vertex and return boolean type
     */
    @Override
    public boolean hasVertex(T vertex) {
        for (int i = 0; i < numVertices; i++) {

            if (this.vertices[i].equals(vertex)) {
                return true;
            }
        }

        return false;
    }

    /*
    this method add weight to vertex and when we add weigt it add one current weight
     */
    @Override
    public void addEdge(T fromVertex, T toVertex, int weight) {

        int row;
        int column;

        row = indexIs(fromVertex);
        column = indexIs(toVertex);
        String convertToStringRow = String.valueOf(row);
        String convertToStringcolumn = String.valueOf(column);

      //  graph.addEdge("",convertToStringRow,convertToStringcolumn);



        edges[row][column] += weight;
        edges[column][row] = edges[row][column];

    }

    /*
    this method returm weight of adjecent martix
     */
    @Override
    public int weightIs(T fromVertex, T toVertex) {
        int row;
        int column;

        row = indexIs(fromVertex);
        column = indexIs(toVertex);
        return edges[row][column];
    }


    @Override
    public boolean isEmpty() {
        return numVertices == 0;
    }

    @Override
    public boolean isFull() {
        return numVertices == this.maxVertices;
    }

/*
this method is helper just for another method and return index of vertex
 */
    private int indexIs(T vertex)
    {
        int index = 0;
        while (!vertex.equals(vertices[index]))
            index++;
        return index;
    }



    public String toString() {
        String out = "";
        for(int i = 0; i < edges.length; i++) {
            for(int j = 0; j < edges[i].length; j++) {

                out += edges[i][j] +" ";
            }
            out +="\n";
        }


        return out;
    }

/*
this method find the mosth busy BikeStation
 */
    public void busyStation() {
     int swap = 0;
     int frontStationIndex = 0;
     int toStationIndex = 0;
        for(int i = 0; i < edges.length; i++) {
            for(int j = 0; j < edges[i].length; j++) {
            if(edges[i][j] > swap){

                swap = edges[i][j];
                frontStationIndex =i;
                toStationIndex = j;

            }

            }



        }

        System.out.println( "Most Busy Station " +  vertices[frontStationIndex] );


    }



/*
this is just print all vertex
 */


    public void showVertex() {
        for(int i = 0; i < numVertices;i++) {


            System.out.println(this.vertices[i] + "\n");


        }
    }


}

