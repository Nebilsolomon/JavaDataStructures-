package bag;

import java.util.Iterator;
import java.util.Random;

public class Bag<T> implements BagInterface<T> , Iterable<T>{

    protected final int DEFCAP = 100;
    protected T[]elements;
    protected  int numElements = 0;


    private boolean found;
    private int location;

    public Bag() {

        elements = (T[]) new Object[DEFCAP];
    }

    @Override
    public boolean add(T element) {
        if(isFull()) {

            return false;
        }
        else {
            elements[numElements] = element;
            numElements++;
            return true;

        }

    }

    @Override
    public T get(T target) {
        find(target);
        if(found) {
            return elements[location];
        }else {
            return null;
        }

        }

    @Override
    public boolean contains(T target) {
        find(target);
        return found;
    }

    @Override
    public boolean remove(T target) {
        find(target);

        if(found) {

            elements[location] = elements[numElements -1] ;
            elements[numElements -1] = null;
            numElements--;
            return true;
        }
        else {
            return false;
        }

    }

    @Override
    public boolean isFull() {
        return numElements == elements.length;
    }

    @Override
    public boolean isEmpty() {
        return numElements == 0;
    }

    @Override
    public int size() {
        return numElements;
    }


    @Override
    public T grab() {
        int randomIndex;
        Random input = new Random();


        if(isEmpty()) {
            return null;
        }else {
            randomIndex = input.nextInt(numElements);
            T hold = elements[randomIndex];

            elements[randomIndex] = elements[numElements-1];
            elements[numElements-1] = null;
            numElements--;

            return hold;
        }


    }

    @Override
    public int count(T target) {
        int count = 0;
        for(int i = 0 ; i < numElements; i++) {
           if(elements[i].equals(target)) {
               count++;
           }

        }

        return count;
    }

    @Override
    public int removeAll(T target) {
       int count = 0;
     if(isEmpty()) {

         System.out.println("it is empty");
     }
     else {

        for(int i = 0 ; i < numElements; i++) {

           // if(elements[i].equals(target)) {

                Iterator<T> input = this.iterator();
                while(input.hasNext()) {
                    if(input.next().equals(target)) {
                     input.remove();
                     count++;

                    }

                }




         //   }

        }
     }


        return count;
    }

    @Override
    public void clear() {
    if(isEmpty()) {
        System.out.println("bag is empty");
    }
    else {
        for(int i = 0; i < numElements; i++) {
            elements[i] = null;
            numElements = 0;
        }


    }



    }

    private void find(T target) {
       location = 0;
       found =false;


       while (location < numElements) {

           if(elements[location].equals(target)) {
               found = true;
               return;
           }
           else {
               location++;
           }

       }



    }


    @Override
    public String toString() {
        String out = "";

        for(int i = 0 ; i < numElements; i++) {
            out = out + elements[i] + " ";
        }


        return out;
    }

    private void removeByIndex (int index)

    {

            for (int i = index; i <= numElements - 2; i++)
                elements[i] = elements[i+1];
            elements[numElements - 1] = null;
            numElements--;

    }


    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            int currentPos = -1;
            @Override
            public boolean hasNext() {
                if((currentPos +1) < size()) {
                    return true;
                }
                else {
                    return false;
                }

            }

            @Override
            public T next() {
                currentPos++;
                return elements[currentPos];
            }

            @Override
            public void remove() {
      for(int i = currentPos; i < numElements -1; i ++) {
          elements[i] = elements[i+1];

      }
      numElements--;

            }
        };
    }
}
