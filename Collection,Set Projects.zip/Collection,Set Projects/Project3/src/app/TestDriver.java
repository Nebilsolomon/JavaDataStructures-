package app;

import bag.Bag;

public class TestDriver {

    public static void main(String[] args) {

        Bag<String> input = new Bag<>();

  //ann, bob, ann, sam
        System.out.println("add 5 name");
        input.add("ann");
        input.add("bob");
        input.add("ann");
        input.add("sam");
        input.add("ann");
        System.out.println(input);
        System.out.println("========================");
        System.out.println("delete all ann");
        input.removeAll("ann");
        System.out.println(input);
        System.out.println("========================");
        input.add("nebil");
        input.add("john");
        System.out.println("add 2 another name");
        System.out.println(input);
        System.out.println("=======================");
        System.out.println("gran rendom name");
        System.out.println(input.grab());


        System.out.println("======================");
        System.out.println("remove all name");
        input.clear();
        System.out.println(input);







    }
}
