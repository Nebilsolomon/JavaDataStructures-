package app;

import banking.BankAccount;
import banking.BankingComparators;
import banking.CheckingAccount;
import banking.SavingsAccount;
import collections.ArrayCollection;
import collections.CollectionInterface;


public class TestMe {
	
	public static void main(String[] args) {
		CollectionInterface<BankAccount> accounts = new ArrayCollection<>();
		accounts.add(new CheckingAccount("Sam", "Daniels", 2300, 500));
		accounts.add(new CheckingAccount("Ann", "Whitman", 1200, 350));
		accounts.add(new SavingsAccount("Sony", "Riemann", 5000, 2000));
		accounts.add(new SavingsAccount("Kyle", "Riemann", 4000, 1800));
		accounts.add(new CheckingAccount("Kyla", "Amberland", 8000, 2300));
		
		//a) Iterating through all the accounts


		for(BankAccount b: accounts) {
			System.out.println(b);
		}



		//Sorting the accounts according to the balance value
		accounts.sort(BankingComparators.getBalanceComparator());
		System.out.println("\n Sorted list of bank accounts according to balance (ascending order):");
		System.out.println(accounts + "\n");
		//testing if you sorted correctly, do not change this code below
		int counter = 0;
	    for(BankAccount b: accounts) {
	    	if(counter == 0)
	    		assert Double.compare(b.getBalance(), 1200) == 0;
	    	else if(counter == 1)
	    		assert Double.compare(b.getBalance(), 2300) == 0;
	    	else if(counter == 2)
	    		assert Double.compare(b.getBalance(), 4000) == 0;
	    	else if(counter == 3)
	    		assert Double.compare(b.getBalance(), 5000) == 0;
	    	else if(counter == 4)
	    		assert Double.compare(b.getBalance(), 8000) == 0;
	    	counter++;
	    }
		
		
		//Sorting the accounts according to the surname - alphabetical order
		accounts.sort(BankingComparators.getSurnameComparator());
		System.out.println("\n Sorted list of bank accounts according to customer surnames (ascending order):");
		System.out.println(accounts + "\n");
		counter = 0;
		
		//testing if you sorted correctly, do not change this code below
	    for(BankAccount b: accounts) {
	    	if(counter == 0)
	    		assert b.getSurname().compareTo("Amberland") == 0;
	    	else if(counter == 1)
	    		assert b.getSurname().compareTo("Daniels") == 0;
	    	else if(counter == 2)
	    		assert b.getSurname().compareTo("Riemann") == 0;
	    	else if(counter == 3)
	    		assert b.getSurname().compareTo("Riemann") == 0;
	    	else if(counter == 4)
	    		assert b.getSurname().compareTo("Whitman") == 0;
	    	counter++;
	    }

 	}



}
