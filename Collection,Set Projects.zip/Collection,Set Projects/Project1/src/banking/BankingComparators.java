package banking;

import java.util.Comparator;

public class BankingComparators {

   public static Comparator getBalanceComparator(){
       return new Comparator<BankAccount>() {
           @Override
           public int compare(BankAccount o1, BankAccount o2) {
               if(o1.getBalance() > o2.getBalance()) {
                   return 1;
               }
               else if(o1.getBalance() < o2.getBalance()) {
                   return -1;
               }
               else {
                   return 0;
           }
       }
   };

}



public static Comparator  getSurnameComparator(){
    return new Comparator<BankAccount>() {
        @Override
        public int compare(BankAccount o1, BankAccount o2) {
            return o1.getSurname().compareTo(o2.getSurname());
        }
    };
}

}