package banking;

public abstract class BankAccount {

  protected String name;
  protected  String surname;
  protected double balance;

  public BankAccount(String name,String lastname, double balance) {
      this.name = name;
      this.surname = lastname;
      this.balance = balance;
  }
    public abstract boolean withdraw(double amount) throws Exception;

    public abstract void depositMoney(Double amount) throws Exception;


    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    public String getSurname() {
        return surname;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }


    @Override
    public String toString() {
        return  getName() +" "+getSurname() + " Balance is " + getBalance();
    }
}
