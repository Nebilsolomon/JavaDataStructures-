package banking;

public class SavingsAccount extends BankAccount {
   protected  double annual_interest_rate;

    public SavingsAccount(String name,String lastname, double balance, double annual_interest_rate) {

        super(name, lastname, balance);
        this.annual_interest_rate = annual_interest_rate;
    }

    @Override
    public boolean withdraw(double amount) throws Exception {
        if(amount > super.balance) {
            throw  new Exception("amount of withdraw has to less than balance");
        }
        else {
         super.balance = super.balance - amount;
         return true;
        }
    }

    @Override
    public void depositMoney(Double amount) {
        if(amount < 0) {
            System.out.println("amount has to be positive");
        }
        else {

            super.balance = super.balance + amount;
        }

    }

    public double getAnnual_interest_rate() {
        return annual_interest_rate;
    }

    public void newBalanceWithAnnual_interest_rate() {

        balance = balance + (balance * getAnnual_interest_rate() / 100);

    }



    @Override
    public String toString() {
        return super.toString() + " annual_interest_rate= " + annual_interest_rate;
    }

}
