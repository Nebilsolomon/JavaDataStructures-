package banking;

public class CheckingAccount extends BankAccount {

 protected double overdraft;

    public CheckingAccount(String name,String lastname, double balance,double overdraft) {

        super(name, lastname, balance);
        this.overdraft = overdraft;

    }

    @Override
    public boolean withdraw(double amount) throws Exception {
        if(super.getBalance() - amount < 0) {

            if(((balance-overdraft) - amount) <= -100) {
                throw  new Exception("you dont have enoug money");

            }else {
                balance = balance -(amount + overdraft);
              return true;
            }


        }
        else {
            super.balance = super.balance-amount;
            return true;
        }
    }

    public double getOverdraft() {
        return overdraft;
    }

    public void setOverdraft(double overdraft) {
        this.overdraft = overdraft;
    }

    @Override
    public void depositMoney(Double amount) {
        if(amount < 0) {
            System.out.println("amount has to be positive");
        }
        else {

            super.balance = super.balance + amount;
        }

    }

    @Override
    public String toString() {
        return  super.toString() +" overdraft = " + overdraft;
    }


}
