package collections;

import support.SetInterface;

public class Set<T> implements SetInterface<T> {

    protected final int DEFCAP = 100;
    protected T[] elements;
    protected int numElements = 0;
    protected boolean found;
    protected int location;

    public Set() {

        elements = (T[]) new Object[DEFCAP];
    }


    @Override
    public boolean add(T element) {

        if (!this.contains(element))
        {
           elements[numElements] = element;
           numElements++;
            return true;
        }
        else {
            return false;

        }

    }

    @Override
    public T indexOf(int index) {
        if(index < 0 || index > numElements) {
            return null;
        }
        else {
            return elements[index];
        }

    }

    @Override
    public T get(T target) {

        find(target);
        if (found) {
            return elements[location];
        }
        else {
            return null;
        }
    }

    @Override
    public boolean contains(T target) {
        find(target);
        return found;
    }

    @Override
    public boolean remove(T target) {
        find(target);
        if(found) {

       elements[location] = elements[numElements-1];
       elements[numElements-1] = null;
       numElements--;
       return true;
        }
        else  {
            return false;
        }



    }

    @Override
    public boolean isFull() {
        return (numElements == elements.length);
    }

    @Override
    public boolean isEmpty() {
        return (numElements == 0);
    }

    @Override
    public int size() {
        return numElements;
    }


    private void find(T target)

    {
        location = 0;
        found = false;

        while (location < numElements)
        {
            if (elements[location].equals(target))
            {
                found = true;
                return;
            }
            else
                location++;
        }
    }

    @Override
    public String toString() {
        String out = "";
        for(int i = 0; i < numElements; i++ ) {
            out = out + elements[i]+ " ";
        }
        return out;
    }




    @Override
    public Set<T> union(Set<T> mySet) {
        Set<T> newSet = new Set<>();

        for(int i = 0 ; i < numElements; i++) {
            newSet.add(elements[i]);

            for(int j = 0; j < mySet.size(); j++) {
                newSet.add(mySet.indexOf(j));



            }

        }

        return newSet;
    }

    @Override
    public Set<T> intersection(Set<T> mySet) {

        Set<T> newSet = new Set<>();
        for(int i = 0 ; i < numElements; i++) {

            for(int j = 0; j < mySet.size(); j++) {
                if(elements[i].equals(mySet.indexOf(j))) {
                    newSet.add(elements[i]);

                }

            }

        }


        return newSet;

    }

    @Override
    public Set<T> difference(Set<T> mySet) {
        Set<T> newSet = new Set<>();
        for(int i = 0 ; i < numElements; i++) {

            for(int j = 0; j < mySet.size(); j++) {

                newSet.add(elements[i]);
                newSet.add(mySet.indexOf(j));


            }


        }
        for(int k = 0; k < mySet.size(); k++) {

            newSet.remove(mySet.indexOf(k));

        }

        return newSet;



    }
}
