package app;
import collections.Set;

/**
 * Do not change anything in the main method. Your code should be made in such a way that all the tests succeed below.
 * Use -ea flags when running the code (assertions will not be seen otherwise)
 * @author irma
 *
 */

public class TestSet {

	public static void main(String[] args) {
		Set<String> mySet1 = new Set<>();
		assert mySet1.add(new String("banana")) == true;
		assert mySet1.add(new String("apple")) == true;
		assert mySet1.add(new String("orange")) == true;
		assert mySet1.add(new String("banana")) == false; //cannot add! banana is already in the set. No duplicates allowed.
		assert mySet1.add(new String("kiwi")) == true;
		
		Set<String> mySet2 = new Set<>();
		assert mySet2.add(new String("grapefruit")) == true;
		assert mySet2.add(new String("apple")) == true;
		assert mySet2.add(new String("orange")) == true;
		assert mySet2.add(new String("avocado")) == true; 
		assert mySet2.add(new String("papaya")) == true;
		
		Set<String> unionSet = mySet1.union(mySet2);
		System.out.println(unionSet);
		assert unionSet.contains("banana") == true;
		assert unionSet.contains("apple") == true;
		assert unionSet.contains("orange") == true;
		assert unionSet.contains("kiwi") == true;
		assert unionSet.contains("grapefruit") == true;
		assert unionSet.contains("avocado") == true;
		assert unionSet.contains("papaya") == true;
		assert unionSet.size() == 7;
		
		
		//SET INTERSECTION
		Set<String> setIntersection = mySet1.intersection(mySet2); //the set of all elements that are both in mySet1 and mySet2
		System.out.println("INTERSECTION: " + setIntersection);
		assert setIntersection.contains("apple") == true;
		assert setIntersection.contains("orange") == true;
		assert setIntersection.size() == 2;
		
		
		//SET DIFFERENCE
		Set<String> setDifference1 = mySet1.difference(mySet2); //the set of all elements in mySet1 that are not in mySet2
		System.out.println("DIFF1: " + setDifference1);
		assert setDifference1.contains("banana") == true;
		assert setDifference1.contains("kiwi") == true;
		assert setDifference1.size() == 2;
		
		Set<String> setDifference2 = mySet2.difference(mySet1); //the set of all elements in mySet2 that are not in mySet1
		System.out.println("DIFF2:" + setDifference2);
		assert setDifference2.contains("grapefruit") == true;
		assert setDifference2.contains("avocado") == true;
		assert setDifference2.contains("papaya") == true;
		assert setDifference2.size() == 3;
		
		//checking terminal cases
		Set<String> mySet3 = new Set<>();
		assert mySet3.add(new String("banana")) == true;
		assert mySet3.add(new String("apple")) == true;
		assert mySet3.add(new String("orange")) == true;		
		Set<String> mySet4 = new Set<>();
		assert mySet4.add(new String("banana")) == true;
		assert mySet4.add(new String("apple")) == true;
		assert mySet4.add(new String("orange")) == true;
		
		Set<String> unionSet2 = mySet3.union(mySet4);
		assert unionSet2.contains("banana") == true;
		assert unionSet2.contains("apple") == true;
		assert unionSet2.contains("orange") == true;
		assert unionSet2.size() == 3;
		
		Set<String> intersection2 = mySet3.intersection(mySet4);
		assert intersection2.contains("banana") == true;
		assert intersection2.contains("apple") == true;
		assert intersection2.contains("orange") == true;
		assert intersection2.size() == 3;
		
		Set<String> differenceExtreme = mySet3.difference(mySet4);
		assert differenceExtreme.size() == 0;
		
		Set<String> mySet5 = new Set<>();
		assert mySet5.add(new String("banana")) == true;
		assert mySet5.add(new String("apple")) == true;
		assert mySet5.add(new String("orange")) == true;		
		Set<String> mySet6 = new Set<>();
		assert mySet6.add(new String("papaya")) == true;
		assert mySet6.add(new String("avocado")) == true;
		assert mySet6.add(new String("kiwi")) == true;

		Set<String> unionSet3 = mySet5.union(mySet6);
		assert unionSet3.contains("banana") == true;
		assert unionSet3.contains("apple") == true;
		assert unionSet3.contains("orange") == true;
		assert unionSet3.contains("papaya") == true;
		assert unionSet3.contains("avocado") == true;
		assert unionSet3.contains("kiwi") == true;
		assert unionSet3.size() == 6;

		System.out.println("nebil Test");

	}

}
