package support;

import collections.Set;

public interface SetInterface<T> extends CollectionInterface<T> {

    Set<T> union(Set<T> mySet);
    Set<T> intersection(Set<T> mySet);
    Set<T> difference(Set<T> mySet);



}
