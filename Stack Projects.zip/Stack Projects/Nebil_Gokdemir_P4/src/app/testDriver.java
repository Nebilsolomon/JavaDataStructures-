

package app;
import stack.EditString;
import stack.StackOverflowException;
import stack.StackUnderflowException;

public class testDriver {
    public static void main(String[] args)throws StackUnderflowException, StackOverflowException {
      /*
      when we create EditString object so its constructor work so we can edit string and push stack
       */

       new EditString();

    }

}
