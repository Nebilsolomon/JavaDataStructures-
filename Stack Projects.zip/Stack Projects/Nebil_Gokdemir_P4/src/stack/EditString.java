package stack;

import java.util.Scanner;

public class EditString {
 // this string is for string to edit
    String stringInput = "";
 // this String  is for prompts repeatedly ask user untel user input X
    String input = "";


    StackInterface<String> stack;

    Scanner scanner = new Scanner(System.in);

    public EditString() throws StackOverflowException, StackUnderflowException {
/*
  Created 10 capacity in stack

 */
        stack = new ArrayBoundedStack<>(10);
        System.out.println("please enter one String");
       // assign string for editing from user
        stringInput = scanner.nextLine();
        stack.push(stringInput);
        System.out.println("type For Exit = X ,LoweCase = L, UpperCase = U, Reverse = R, C ch1 ch2—change = C ,undo =Z");
       // assign string from user
        input = scanner.nextLine();

      /*
      this method call method  editStringg.
       */
        editStringg();

    }

    public void editStringg() throws StackUnderflowException ,StackOverflowException{

 // this while loop work untel user enter X
        while (!(input.equals("X"))) {

    /*
     if user enter U or u this method will pick up top in stack and use toUpperCase
      method and push stack again.
     */
     if (input.equals("U") || input.equals("u")) {
         stringInput = stack.top().toUpperCase();
         stack.push(stringInput);

     }
       /*
     if user enter L or l this method will pick up top in stack and use toLowerCase
      method and push stack again.
     */

     else if (input.equals("L") || input.equals("l")) {
         stringInput = stack.top().toLowerCase();
         stack.push(stringInput);

     }

       /*
     if user enter R or r this method will pick up top in stack and put StringBuffer as parameter
     and use reverse method in this object and convert string with toString method and then push stack
     */

     else if (input.equals("R") || input.equals("r")) {
         stringInput  = new StringBuffer(stack.top()).reverse().toString();
         System.out.println(stringInput);
         stack.push(stringInput);

     }


     /*
     this method get first characher of string and if it is C or c
     assignt stringInput top stack and use replace method change  1 characher  to all 2 characher
     and then push this to stack
      */
     //input.equals("C") || input.equals("c")

     else if((input.charAt(0)== 'C')){

        String stringInput =  stack.top();
         stringInput =  stringInput.replace(input.charAt(2),input.charAt(4));
         System.out.println(stringInput);
         stack.push(stringInput);
     }

     /*
      if user enter Z or z this method will pop top so it will be perivous index.
      */

     else if (input.equals("Z") || input.equals("z")) {

         stack.pop();
     // stringInput = stack.top();
     }

            System.out.println("type Exit = XFor LoweCase = L, UpperCase = U, Reverse = R, C ch1 ch2—change = C ,undo =Z");
            input = scanner.nextLine();

        }
        System.out.println(stack);

    }



}







