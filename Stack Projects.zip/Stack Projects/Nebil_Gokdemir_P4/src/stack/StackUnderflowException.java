package stack;

public class StackUnderflowException extends Exception {

    public StackUnderflowException() {
        // TODO Auto-generated constructor stub
    }

    public StackUnderflowException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public StackUnderflowException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public StackUnderflowException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public StackUnderflowException(String message, Throwable cause, boolean enableSuppression,
                                   boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        // TODO Auto-generated constructor stub
    }



}
