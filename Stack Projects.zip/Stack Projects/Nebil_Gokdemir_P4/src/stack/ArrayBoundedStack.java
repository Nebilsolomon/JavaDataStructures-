package stack;

public class ArrayBoundedStack<T> implements StackInterface<T> {


    protected T[] elements;
    protected int topIndex = -1;
    protected int capacity;

    public ArrayBoundedStack(int capacity) {
        this.elements = (T[]) new Object[capacity];
        this.capacity = capacity;
    }

    @Override
    public void push(T info) throws StackOverflowException {
        if (isFull()) {
            throw new StackOverflowException("The stack is full!");
        }
        //topIndex++;
        elements[++topIndex] = info;
    }

    @Override
    public void pop() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("The stack is empty!");
        }
        elements[topIndex--] = null;
        //topIndex--;

    }

    @Override
    public T top() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("The stack is empty!");
        }
        return elements[topIndex];
    }

    @Override
    public boolean isFull() {
        return topIndex == elements.length - 1;
    }

    @Override
    public boolean isEmpty() {
        return topIndex == -1;
    }

    @Override
    public int size() {
        return this.topIndex + 1;
    }



    public String toString() {
        String stackString = "";
        if(isEmpty()) {
            try {
                throw  new StackUnderflowException("Stack is empty");
            }catch (StackUnderflowException e) {
                System.out.println(e.getMessage());
            }
        }


        for(int i = 0; i <=topIndex; i++ ) {

            stackString= stackString+ "" +elements[i] +" ||";
        }


        return stackString;

    }

}




