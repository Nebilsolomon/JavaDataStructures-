package app;

import interfacePackage.PairInterface;
import pair.ArrayPair;
import pair.BasicPair;

public class Driver {
    public static void main(String[] args) {
        PairInterface<String> myPair = new BasicPair<>("apple","peach");
        System.out.println("THis is for BasicPair Class");
        System.out.print( myPair.getFirst() + " ");
        myPair.setSecond(" orange ");
        System.out.println(myPair.getSecond());
        System.out.println(myPair);

        System.out.println("====================");




        System.out.println("THis is for ArrayPair Class");
        PairInterface<String> myPair2 = new ArrayPair<>();
        myPair2.setFirst("swift");
        myPair2.setSecond("java");
        System.out.println(myPair2);
    }
}
