package pair;

import interfacePackage.PairInterface;

public class BasicPair<T> implements PairInterface<T> {

    protected T first;
    protected T second;


    public  BasicPair(T first, T second) {
        this.first = first;
        this.second = second;

    }

        /*
this method set  second pair
*/

    @Override
    public void setSecond(T second) {
        this.second = second;

    }

    /*
this method set  first pair
*/
    @Override
    public void setFirst(T first) {
        this.first = first;

    }

    /*
this method return second pair
*/
    @Override
    public T getSecond() {
        return this.second;
    }

  /*
this method return first pair
 */

    @Override
    public T getFirst() {
        return this.first;
    }
/*
this method return first and second pair as string
 */
    @Override
    public String toString() {
        return getFirst() + " " + getSecond();
    }
}
