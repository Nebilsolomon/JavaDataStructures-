package pair;

import interfacePackage.PairInterface;


public class ArrayPair<T> implements PairInterface<T> {

    protected T[] arrayPair;


  public ArrayPair () {
      arrayPair = (T[]) new Object[2];

  }


    /*
    this method set second index of array
     */
    @Override
    public void setSecond(T second) {
    arrayPair[1] = second;
    }

    /*
    this method set first index of array
     */
    @Override
    public void setFirst(T first) {
  arrayPair[0] = first;
    }

    /*
    this method return second indext of array
     */
    @Override
    public T getSecond() {
        return arrayPair[1];
    }

    /*
    this method return first index of Array
     */
    @Override
    public T getFirst() {
        return arrayPair[0];
    }

    /*
    this method return first and second pair as string
     */
    @Override
    public String toString() {
        return "First PairOfArray is "+ getFirst() + " second  PairOfArray is " + getSecond();
    }
}
