package interfacePackage;

public interface PairInterface<T> {

    public void setSecond(T second);
    public void setFirst(T first);
    public T getSecond();
    public T getFirst();


}
