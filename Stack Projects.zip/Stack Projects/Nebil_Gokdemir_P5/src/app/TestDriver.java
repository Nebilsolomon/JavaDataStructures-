package app;

import stack.LinkedStack;
import stack.StackInterface;
import stack.StackOverflowException;
import stack.StackUnderflowException;

public class TestDriver  {

    public static void main(String[] args) throws StackOverflowException, StackUnderflowException {

        StackInterface<String> stack = new LinkedStack<>();




        stack.push("A");
        stack.push("B");
        stack.push("A");
        stack.push("B");

        System.out.println("Is stack has duplicate = " + stack.isDuplicate());
        System.out.println("BEFORE DELETE IT");


       stack.show();

        System.out.println("AFTER DELETE IT");
        stack.deleteDuplicate();

        stack.show();







    }
}
