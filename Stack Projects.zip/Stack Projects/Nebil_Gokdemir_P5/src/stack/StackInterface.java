package stack;

public interface StackInterface<T> {

    /**
     * Adding an element to the top of the stack
     * @param info - the element to be added to the stack
     * @throws StackOverflowException
     */
    void push(T info) throws StackOverflowException;

    /**
     * Remove the top element.
     * @throws StackUnderflowException
     */
    void pop() throws StackUnderflowException;

    /**
     * Get the top element.
     * @return
     * @throws StackUnderflowException
     */
    T top() throws StackUnderflowException;

    boolean isFull();
    boolean isEmpty();
    int size();
   public void show();

   public boolean isDuplicate();
   public void deleteDuplicate();
}
