package stack;

import support.LLNode;

public class LinkedStack<T> implements StackInterface <T> {

    protected LLNode<T> top;
    private int size;

    public LinkedStack() {
        top = null;
        size = 0;
    }

    public LinkedStack(T data) {
        top = new LLNode<T>(data);
        size = 1;
    }

    @Override
    public void push(T info) throws StackOverflowException {
        LLNode<T> newNode = new LLNode<T>(info);
        newNode.setNext(top);
        top = newNode;
        this.size++;
    }

    @Override
    public void pop() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("Your stack is empty");
        }
        top = top.getNext();
        this.size--;
    }

    @Override
    public T top() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException("Your stack is empty");
        }
        return top.getData();
    }

    @Override
    public boolean isFull() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isEmpty() {
        return top == null;
    }

    @Override
    public int size() {

        return this.size;
    }

    public void show() {
        LLNode<T> head = top;

        while (head != null) {

            System.out.println(head.getData());
            head = head.getNext();
        }


    }

    /*
    this method check if there is same element in linkList.
     */

    public boolean isDuplicate() {

        Boolean truOrFalse = false;
        LLNode<T> head = top;

        while (head != null) {


            LLNode<T> node = head.getNext();

            while (node != null) {

                if (node.getData() == head.getData()) {
                    truOrFalse = true;

                }

                node = node.getNext();
            }
            head = head.getNext();

        }
        return truOrFalse;
    }



/*
this method check if there is same element in list. delete one same element in link
 */

    public void deleteDuplicate() {

        LLNode<T> head = top;

        while(head != null) {


            LLNode<T> node = head.getNext();


            while(node != null) {
            LLNode<T> temp = top;

                if( head.getData() == node.getData()) {

                   // System.out.println("nebil gokdemir");


                    if(head == top) {
                  head = head.getNext() ;

                    }
                    else {

                  while(temp.getNext() != head) {


                      temp = temp.getNext();

                  }
                        temp = head.getNext();
                       top = temp;


                    }




                }
              //  temp = temp.getNext();
                node = node.getNext();
            }
            head = head.getNext();

        }

    }
}











