package interFacePackage;

public interface Flying {

    void fly ();
}
