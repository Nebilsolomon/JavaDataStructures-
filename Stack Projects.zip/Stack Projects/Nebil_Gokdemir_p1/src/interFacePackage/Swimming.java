package interFacePackage;

public interface Swimming {
    void swim ();
}
