package interFacePackage;

public interface Walking {
    void walk ();
}
