package app;

import animal.Duck;

public class Driver {

    public static void main(String[] args) {
        Duck d = new Duck ();
        d.eat();
        d.swim ();
        d.walk ();
         d.fly ();

    }
}
