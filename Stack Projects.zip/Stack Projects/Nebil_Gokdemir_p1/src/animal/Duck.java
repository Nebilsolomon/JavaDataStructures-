package animal;

import interFacePackage.Flying;
import interFacePackage.Swimming;
import interFacePackage.Walking;
/*
Duck class extend abstrack Animal class and implements Flying, Swimming, Walking interface
so that duck class implement all method from those
 */
public class Duck extends Animal implements Flying, Swimming, Walking {

/*
overide from animal abstrack class
*/
    @Override
    public void eat() {
        System.out.println("i eat seaFood :)");
    }
    /*
    implement from Flying interface 
    */

    @Override
    public void fly() {
        System.out.println("I can fly");
    }

    /*
     implement from Swimming interface 
    */

    @Override
    public void swim() {
        System.out.println("I can swim");
    }


 /*
     implement from Walking interface 
    */

    @Override
    public void walk() {

        System.out.println("I can walk");
    }
}
