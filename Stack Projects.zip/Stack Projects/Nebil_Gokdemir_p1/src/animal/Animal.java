package animal;

public abstract class Animal {
   public abstract void eat ();
}
