package app;

import stack.BoundedArrayStack;
import stack.StackInterface;
import stack.StackOverflowException;
import stack.StackUnderflowException;

public class TestDriver {
    public static void main(String[] args) {
        StackInterface<String> stack = new BoundedArrayStack<>(10);

       try {
             stack.push("java");
             stack.push("swift");
             stack.push("android");
             stack.push("c++");
             stack.push("pyhton");
             stack.push("c");

           System.out.println(stack.size());
           stack.popSome(2);
           System.out.println(stack.toString());






       }catch (StackOverflowException e) {

           System.out.println(e.getMessage());
       }catch (StackUnderflowException e) {
           System.out.println(e.getMessage());
       }
    }
}
