package stack;

public class BoundedArrayStack<T> implements StackInterface<T> {

    protected T[] elements;
    protected int topIndex = -1;
    protected int capacity;


    public BoundedArrayStack(int capacity) {
        this.elements = (T[]) new Object[capacity];
        this.capacity = capacity;
    }

    @Override
    public void push(T info) throws StackOverflowException {
        if(isFull()) {
            throw new StackOverflowException("The stack is full!");
        }
        //topIndex++;
        elements[++topIndex] = info;
    }

    @Override
    public void pop() throws StackUnderflowException {
        if(isEmpty()) {
            throw new StackUnderflowException("The stack is empty!");
        }
        elements[topIndex--] = null;
        //topIndex--;

    }

    @Override
    public T top() throws StackUnderflowException {
        if(isEmpty()) {
            throw new StackUnderflowException("The stack is empty!");
        }
        return elements[topIndex];
    }

    @Override
    public boolean isFull() {
        return topIndex == elements.length - 1;
    }

    @Override
    public boolean isEmpty() {
        return topIndex == -1;
    }


/*
this method give all element in stack as String
 */

    public String toString() {
        String stackString = "";
        if(isEmpty()) {
            try {
            throw  new StackUnderflowException("Stack is empty");
            }catch (StackUnderflowException e) {
                System.out.println(e.getMessage());
            }
        }


        for(int i = 0; i <=topIndex; i++ ) {

                stackString= stackString+ " || " +elements[i];
        }


        return stackString;

        }


/*
this method give size of element is stack
 */
        public int size() {
        int count = 0;
        for(int i = 0; i< topIndex+1; i++) {

            count++;
        }

       return count;
        }


/*
 @Override
    public int size() {
        return this.topIndex + 1;
    }
 */


/*
this method delete elements base on count
 */
    public boolean popSome(int count) throws StackUnderflowException{
    boolean truOrFalse = false;
        if( topIndex >= -1 ) {

            for(int i = 0; i < count; i++) {
                elements[topIndex] = null;
                topIndex = topIndex -1;
                truOrFalse = true;

            }

        }
        else {
            truOrFalse = false;
            throw  new StackUnderflowException("count is bigger than stack elements");
        }

        return  truOrFalse;
    }




    }




