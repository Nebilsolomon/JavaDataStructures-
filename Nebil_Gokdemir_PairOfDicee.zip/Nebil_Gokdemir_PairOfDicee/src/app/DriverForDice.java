package app;

import dice.PairOfDice;
import dice.UnfairDice;


public class DriverForDice {

    public static void main(String[] args) {

        PairOfDice pairOfDice = new PairOfDice();
        UnfairDice unfairDice = new UnfairDice();



        System.out.println(pairOfDice);
        System.out.println(unfairDice);

    }
}
