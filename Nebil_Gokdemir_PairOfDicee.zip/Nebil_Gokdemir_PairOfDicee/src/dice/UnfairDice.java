package dice;

import module.Dice;

public class UnfairDice extends Dice {

 /*
 this method override from dice and we set diceone 10 and dice2 5
  */
    @Override
    public void roll() {
        super.setDice1(10);
       super.setDice2(5);

    }

    /*
    this method override from dice and it return sum of dices
     */
    @Override
    public int value() {
        return super.value();
    }

    /*
    this method override frrom dice and return dices and sum of them as String
     */

    @Override
    public String toString() {
        return super.toString();
    }
}
