package dice;

import module.Dice;

public class PairOfDice extends Dice {

   public PairOfDice() {

   super();
   }
/*
this method override from Dice and assign dice1 and dice2 to random number from 1 to 6

 */

    @Override
    public void roll() {

        super.setDice1((int)(Math.random()*6) + 1);
        super.setDice2((int)(Math.random()*6) + 1);


    }

    /*
    this method also override from Dice class and it return sum of dice
     */
    @Override
    public int value() {
        return super.value();
    }

    /*
    this method override from dice and it return dice1 and dice2 and sum of them as String
     */

    @Override
    public String toString() {
        return super.toString();
    }
}
