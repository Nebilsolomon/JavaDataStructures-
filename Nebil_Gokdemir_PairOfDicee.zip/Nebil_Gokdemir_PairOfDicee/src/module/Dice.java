package module;

public class Dice {

   private int dice1 ;
   private int dice2;


   public Dice() {
       roll();
   }


    public void roll () {

    }

    // this methoh return dice1
    public int getDice1() {
        return dice1;
    }

    // this method return dice2
    public int getDice2() {
        return dice2;
    }

    // this method return sum of dice
    public int value() {

        return dice2 + dice1;
    }

    public void setDice1(int dice1) {
        this.dice1 = dice1;
    }

    public void setDice2(int dice2) {
        this.dice2 = dice2;
    }

    /*
    this method override from object class and it return dice1 and dice 2 and sum of them
    and also i convert dice1, dice2 and sum of them to String to use valuuOf method

     */

    @Override
    public String toString() {
       String dice1Convert = String.valueOf(dice1);
        String dice2Convert = String.valueOf(dice2);
        String sumConvert = String.valueOf(value());

        return dice1Convert + ":" + dice2Convert + "=" + sumConvert;
    }
}
