package fizzBuzz;

public class FizzBuzz {


    public String[] fizzBuzz(int start, int end) {
      String []returnString = new String[100];

    for(int i = start; i < end; i++ ) {

        if( (i % 3) == 0 && (i % 5) == 0) {

            returnString[i] = "FizzBuzz";

        }
        else if(( i % 3) == 0 ) {

            returnString[i] = "Fizz";

        }
        else if ( (i % 5) == 0) {

            returnString [i] = "Buzz";
        }

        else {

            String convertNumber = String.valueOf(i);

            returnString[i] = convertNumber;


        }


    }


      return returnString;

    }


}
