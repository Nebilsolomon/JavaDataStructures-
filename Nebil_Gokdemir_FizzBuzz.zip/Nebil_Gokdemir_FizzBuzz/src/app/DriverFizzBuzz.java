package app;

import fizzBuzz.FizzBuzz;

public class DriverFizzBuzz {


    public static void main(String[] args) {
        FizzBuzz fizzBuzz = new FizzBuzz();

   for( int i = 1; i < 100; i ++) {
       System.out.println(fizzBuzz.fizzBuzz(1, 100)[i]);

   }
    }





}
