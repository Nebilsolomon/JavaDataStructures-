package map;

import java.util.Iterator;

public class HMap<K,V> implements MapInterface<K,V> {


    protected MapEntry<K,V> head;
    protected int numPairs;

    public HMap() {
    head = null;
    numPairs = 0;

    }



    @Override
    public V get(K k) {

        V vv = null;
        MapEntry<K,V> temp = head;
        while (temp != null) {
            if(temp.getKey().equals(k)) {
               vv = temp.getValue();
            }

            temp = temp.next;
        }

        return vv;

    }


    @Override
    public V put(K k, V v) {
        V vv = null;
        MapEntry<K,V> newMap = new MapEntry<>(k,v);

        MapEntry<K,V> temp = head;
        MapEntry<K,V> prev = null;
        if(temp == null) {
            head  = newMap;
            numPairs++;
        }
        else {

            while (temp != null && !(temp.getKey().equals(k))) {

                prev = temp;
                temp = temp.next;
            }
  if(temp == null) {
      prev.next = newMap;
      numPairs++;
  }
  else {
     // this.remove(k);
  if(temp.equals(head)) {
      vv = head.getValue();
      newMap.next = temp.next;
      head = newMap;
      System.out.println("nebil gokdemirr");
  }
      else {
       vv = temp.getValue();
      newMap.next = temp.next;
      prev.next = newMap;
  }


  }

        }


        return vv;
    }

    @Override
    public V remove(K k) {
     V value = null;
     if(isEmpty()) {
         System.out.println("there is no node");
     }
     else {

         MapEntry<K,V> temp = head;
         MapEntry<K,V> prev = null;

     if(temp != null && temp.getKey().equals(k)) {
         value = temp.getValue();
         head = temp.next;
         numPairs--;
        // return null;
     }
     else {
   while (temp != null && !(temp.getKey().equals(k))) {

       prev = temp;
       temp = temp.next;
   }

   if(temp == null) {
       System.out.println("node doesnt exit");
       return null;
   }
   else {
       value = temp.getValue();
       prev.next = temp.next;
       numPairs--;
   }


     }


     }

     return value;

    }

    @Override
    public boolean contains(K k) {
        boolean xx = false;
        MapEntry<K,V> temp = head;
        while (temp != null) {
            if(temp.getKey().equals(k)) {
                xx = true;
            }

            temp = temp.next;
        }

        return xx;
    }

    @Override
    public boolean isEmpty() {
        return head == null;
    }

    @Override
    public boolean isFull() {
        return false;
    }

    @Override
    public int size() {
        return numPairs;
    }








    @Override
    public String toString() {
       MapEntry<K,V> node = head;
        String mapElement = "";
        while(node != null) {

            mapElement = mapElement + node + "\n";
                    //+ (node.getValue()).toString() + " ";
            node = node.getNext();
        }


        return mapElement;
    }




    @Override
    public Iterator<MapEntry<K, V>> iterator() {
        return new Iterator<MapEntry<K, V>>() {
            @Override
            public boolean hasNext() {
                return false;
            }

            @Override
            public MapEntry<K, V> next() {
                return null;
            }
        };

    }
}
