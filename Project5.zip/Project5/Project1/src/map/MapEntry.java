package map;

public class MapEntry<K, V>
{
  protected K key;
  protected V value;
  protected MapEntry<K,V> next;
  
  MapEntry(K k, V v)
  {
    key = k; value = v;
    next = null;
  }
  
  public K getKey()  {return key;}
  public V getValue(){return value;}
  public void setValue(V v){value = v;}

  public MapEntry<K, V> getNext() {
    return next;
  }

  public void setNext(MapEntry<K, V> next) {
    this.next = next;
  }

  @Override
  public String toString()
  // Returns a string representing this MapEntry.
  {
    return  "[" +"Key = " + getKey() +", Value = " + getValue() +"] ";
  }
}
 