package app;

import map.HMap;

public class TestDriver {
    public static void main(String[] args) {
        HMap<Integer,String> input = new HMap<>();

        System.out.println("add 4 map ");

     input.put(1,"swift");
     input.put(2,"java");
     input.put(3,"C++");
     input.put(4,"C");
        System.out.println(input);

        System.out.println("==========");
        System.out.println("delete 4 map");
        input.remove(4);
        System.out.println(input);

        System.out.println("add map same key C++");
        input.put(3,"javascript");
        System.out.println(input);









    }
}
